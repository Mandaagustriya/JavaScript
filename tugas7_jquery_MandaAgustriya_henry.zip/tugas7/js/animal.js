$(document).ready(function () {
    $('.card-body').each(function () {
      $(this).click(function () {
        let animal = $(this).find('h5').attr('id');
        $('#bunyi').remove();
        $('#gambar').remove();
        if (animal == 'angsa') {
          $(this).prepend(`<img id="gambar" src="img/angsa.png" class="card-img-top">`);
          $(this).find('.audio').append(`<audio src="audio/angsa.mp3" autoplay id="bunyi"></audio>`);
        } else if (animal == 'burung-hantu') {
          $(this).prepend(`<img id="gambar" src="img/burung-hantu.png" class="card-img-top">`);
          $(this).find('.audio').append(`<audio src="audio/burung-hantu.mp3" autoplay id="bunyi"></audio>`);
        } else if (animal == 'camar') {
          $(this).prepend(`<img id="gambar" src="img/camar.png" class="card-img-top">`);
          $(this).find('.audio').append(`<audio src="audio/camar.mp3" autoplay id="bunyi"></audio>`);
        } else if (animal == 'elang') {
          $(this).prepend(`<img id="gambar" src="img/elang.png" class="card-img-top">`);
          $(this).find('.audio').append(`<audio src="audio/elang.mp3" autoplay id="bunyi"></audio>`);
        } else if (animal == 'ayam') {
          $(this).prepend(`<img id="gambar" src="img/ayam.png" class="card-img-top">`);
          $(this).find('.audio').append(`<audio src="audio/ayam.mp3" autoplay id="bunyi"></audio>`);
        } else if (animal == 'sapi') {
          $(this).prepend(`<img id="gambar" src="img/sapi.png" class="card-img-top">`);
          $(this).find('.audio').append(`<audio src="audio/sapi.mp3" autoplay id="bunyi"></audio>`);
        } else if (animal == 'kambing') {
          $(this).prepend(`<img id="gambar" src="img/kambing.png" class="card-img-top">`);
          $(this).find('.audio').append(`<audio src="audio/kambing.mp3" autoplay id="bunyi"></audio>`);
        } else if (animal == 'bebek') {
          $(this).prepend(`<img id="gambar" src="img/bebek.png" class="card-img-top">`);
          $(this).find('.audio').append(`<audio src="audio/bebek.mp3" autoplay id="bunyi"></audio>`);
        } else if (animal == 'macan') {
          $(this).prepend(`<img id="gambar" src="img/macan.png" class="card-img-top">`);
          $(this).find('.audio').append(`<audio src="audio/macan.mp3" autoplay id="bunyi"></audio>`);
        } else if (animal == 'puma') {
          $(this).prepend(`<img id="gambar" src="img/puma.png" class="card-img-top">`);
          $(this).find('.audio').append(`<audio src="audio/puma.mp3" autoplay id="bunyi"></audio>`);
        } else if (animal == 'anjing') {
          $(this).prepend(`<img id="gambar" src="img/anjing.png" class="card-img-top">`);
          $(this).find('.audio').append(`<audio src="audio/anjing.mp3" autoplay id="bunyi"></audio>`);
        } else if (animal == 'simpanse') {
          $(this).prepend(`<img id="gambar" src="img/simpanse.png" class="card-img-top">`);
          $(this).find('.audio').append(`<audio src="audio/simpanse.mp3" autoplay id="bunyi"></audio>`);
        } else if (animal == 'babi') {
          $(this).prepend(`<img id="gambar" src="img/babi.png" class="card-img-top">`);
          $(this).find('.audio').append(`<audio src="audio/babi.mp3" autoplay id="bunyi"></audio>`);
        } else if (animal == 'zoo') {
          $(this).prepend(`<img id="gambar" src="img/zoo.png" class="card-img-top">`);
          $(this).find('.audio').append(`<audio src="audio/zoo.mp3" autoplay id="bunyi"></audio>`);
        }
      });
    });
  });